package com.odoo.core.orm;

/**
 * Created by dpr on 5/4/16.
 */
public enum RelCommands {
    Replace, Append, Delete, Unlink
}
