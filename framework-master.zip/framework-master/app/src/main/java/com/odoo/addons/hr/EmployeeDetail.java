package com.odoo.addons.hr;

public class EmployeeDetail {
}
